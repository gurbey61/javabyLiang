package JavaIII.Hw1;

public class Employee {
    private String fullName;
    private String manager;

    // Default constructor
    public Employee() {

    }

    // Constructor with arguments
    public Employee(String fullName, String manager) {
        this.fullName = fullName;
        this.manager = manager;
    }

    // Getters and Setters

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }
}
