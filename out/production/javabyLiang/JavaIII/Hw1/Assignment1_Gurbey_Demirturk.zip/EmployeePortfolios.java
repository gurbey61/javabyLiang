package JavaIII.Hw1;

// import statements
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EmployeePortfolios {
    public static void collectEmployee() throws IOException {

        // Create the ArrayList
        List<Employee> employeeList = new ArrayList<>();

        // Provide the Path and Load it to the memory
        FileReader fr = new FileReader("src/JavaIII/Hw1/Portfolio.txt");
        BufferedReader br = new BufferedReader(fr);

        // Reading the first line
        String line = br.readLine();

        // Fill the String Array
        while (line != null){
            String manager = "";
            String fullName = "";
            String[] delLine;

            if(line.contains("  ")) {
                delLine = line.split("  "); // split by double space
                fullName = delLine[0];
                manager = delLine[1];

            } else if (line.contains(" \t")) {
                delLine = line.split(" \t"); // split by space and tab
                fullName = delLine[0];
                manager = delLine[1];

            } else {
                fullName = line;
            }

            // Create the employee objects
            Employee employee = new Employee(fullName, manager);

            // Use ArrayList add method to fill the ArrayList with Employee objects
            employeeList.add(employee);

            line = br.readLine(); // Read the next line
        }

        // Call display method to display Employee List
        display(employeeList);

    }

    // display method definition
    public static void display(List<Employee> employees) {
        // For each loop to go through employeeList
        for (Employee employee : employees) {
            System.out.println(employee.getFullName() + " - " + employee.getManager()); // Displays by name
        }
    }

    // main method
    public static void main(String[] args) throws IOException {
        collectEmployee(); // calling collectEmployee method
    }
}